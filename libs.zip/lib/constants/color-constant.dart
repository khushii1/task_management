import 'package:flutter/material.dart';

Color primaryColor=Color(0xff0078ad) ;