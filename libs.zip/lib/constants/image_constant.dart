String imagePath = "assets/images/";

//icons
String jio_logo = "${imagePath}jio_logo.svg";