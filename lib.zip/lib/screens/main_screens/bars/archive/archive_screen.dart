import '../../../../utilities/library.dart';

class ArchiveScreen extends StatelessWidget {
  const ArchiveScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.brown,
    );
  }
}
