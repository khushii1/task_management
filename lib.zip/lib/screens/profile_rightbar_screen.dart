import 'package:flutter/material.dart';

class ProfileRightbarScreen extends StatelessWidget {
  const ProfileRightbarScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold();
  }
}
