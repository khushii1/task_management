import 'package:get/get.dart';

class DeleteController extends GetxController{

}