import 'package:get/get.dart';

class ArchiveController extends GetxController{

}