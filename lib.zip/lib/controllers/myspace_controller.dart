import 'package:get/get.dart';

class MyspaceController extends GetxController{

}