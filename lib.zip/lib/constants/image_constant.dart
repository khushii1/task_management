String imagePath = "assets/images/";
String iconPath = "icons/";

//icons
String jioLogo = "${imagePath}jio_logo.svg";

String workspace = "$iconPath/workspace.svg";

String dashboard = "$iconPath/dashboard.svg";

String archive = "$iconPath/archive-icon.svg";

String setting = "$iconPath/setting.svg";

String project = "$iconPath/project.svg";
String profileIcon = "$iconPath/profile-icon.svg";

String deleteIcon = "$iconPath/delete-icon.svg";

String editIcon = "$iconPath/edit-icon.svg";
String lock = "$iconPath/lock.svg";
String crown = "$iconPath/crown.svg";
String manageUser = "$iconPath/manage-user.svg";

String icon1 = "${imagePath}icon1.svg";
String icon2 = "${imagePath}icon2.svg";
String icon3 = "${imagePath}icon3.svg";
String icon4 = "${imagePath}icon4.svg";
String icon5 = "${imagePath}icon5.svg";
String empty = "${imagePath}empty.svg";
