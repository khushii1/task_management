
// ignore_for_file: file_names

import 'package:flutter/material.dart';

Color primaryColor = const Color(0xff0078ad);
Color color1=const Color(0xffe9f7e9);
Color color2=const Color(0xffffeaed);
Color color3=const Color(0xfffef7e9);
Color color4=const Color(0xfffef0e7);
Color color5=const Color(0xffebebeb);


Color textColor = const Color(0xff595959);
